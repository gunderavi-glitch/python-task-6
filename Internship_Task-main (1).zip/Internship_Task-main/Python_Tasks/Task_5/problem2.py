# Problem 2: String Split and Join
# HackerRank Link: https://www.hackerrank.com/challenges/python-string-split-and-join/problem

#!/bin/python3

import math
import os
import random
import re
import sys


def split_and_join(line):
    words = line.split(" ")
    result = "-".join(words)
    return result


if __name__ == '__main__':
    line = input()
    result = split_and_join(line)
    print(result)
